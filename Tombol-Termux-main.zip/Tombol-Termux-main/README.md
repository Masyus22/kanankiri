# Tombol Termux
```
Tools ini dibuat untuk mempermudah
para pengguna termux pemula, yg bertujuan
untuk menampilkan tombol navigasi di termux
versi terbaru !
```
## How to it?
```python
$ cd Tombol-Termux
$ python main.py
```
> Full Tutorial [click here](https://youtu.be/Iz290PQ3KLk)
## Support Me On
<b>• [Facebook](https://m.facebook.com/dhasilva.junior.3)</b>
<br>
<b>• [Youtube](https://www.youtube.com/channel/UCLRXFyMN0L8yH9F-xxOd7Og)</b>
</br>
